import { 
  type Product, type InsertProduct, 
  type Customer, type InsertCustomer,
  type Invoice, type InsertInvoice,
  type InvoiceItem, type InsertInvoiceItem
} from "@shared/schema";

export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductByBarcode(barcode: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  // Customers
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: number): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  
  // Invoices
  getInvoices(): Promise<Invoice[]>;
  getInvoice(id: number): Promise<Invoice | undefined>;
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  
  // Invoice Items
  getInvoiceItems(invoiceId: number): Promise<InvoiceItem[]>;
  createInvoiceItem(item: InsertInvoiceItem): Promise<InvoiceItem>;
  
  // For reporting
  getPopularProducts(limit: number): Promise<Product[]>;
  getRecentSales(limit: number): Promise<Invoice[]>;
}

export class MemStorage implements IStorage {
  private products: Map<number, Product>;
  private customers: Map<number, Customer>;
  private invoices: Map<number, Invoice>;
  private invoiceItems: Map<number, InvoiceItem>;
  private productIdCounter: number;
  private customerIdCounter: number;
  private invoiceIdCounter: number;
  private invoiceItemIdCounter: number;

  constructor() {
    this.products = new Map();
    this.customers = new Map();
    this.invoices = new Map();
    this.invoiceItems = new Map();
    this.productIdCounter = 1;
    this.customerIdCounter = 1;
    this.invoiceIdCounter = 1;
    this.invoiceItemIdCounter = 1;
    
    // Add a cash customer by default
    this.createCustomer({
      name: "عميل نقدي",
      phone: "",
      email: ""
    });
    
    // Add some sample products
    this.createProduct({
      name: "لابتوب ديل إنسبايرون",
      barcode: "1234567890123",
      sku: "SKU12345",
      price: "1200",
      stockQuantity: 15,
      isPopular: true
    });
    
    this.createProduct({
      name: "هاتف سامسونج جالاكسي",
      barcode: "2234567890123",
      sku: "SKU54321",
      price: "800",
      stockQuantity: 20,
      isPopular: true
    });
    
    this.createProduct({
      name: "هاتف آيفون 13",
      barcode: "3234567890123",
      sku: "SKU67890",
      price: "3999",
      stockQuantity: 15,
      isPopular: true
    });
    
    this.createProduct({
      name: "سماعات ايربودز برو",
      barcode: "4234567890123",
      sku: "SKU09876",
      price: "899",
      stockQuantity: 8,
      isPopular: true
    });
    
    this.createProduct({
      name: "ساعة ابل ووتش",
      barcode: "5234567890123",
      sku: "SKU45678",
      price: "1599",
      stockQuantity: 2,
      isPopular: true
    });
    
    this.createProduct({
      name: "لوحة مفاتيح لاسلكية",
      barcode: "6234567890123",
      sku: "SKU23456",
      price: "199",
      stockQuantity: 20,
      isPopular: true
    });
    
    this.createProduct({
      name: "شاحن سريع 20 واط",
      barcode: "7234567890123",
      sku: "SKU34567",
      price: "79",
      stockQuantity: 12,
      isPopular: true
    });
    
    this.createProduct({
      name: "حقيبة حماية للابتوب",
      barcode: "8234567890123",
      sku: "SKU78901",
      price: "149",
      stockQuantity: 3,
      isPopular: true
    });
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }
  
  async getProductByBarcode(barcode: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(
      (product) => product.barcode === barcode
    );
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.productIdCounter++;
    const newProduct: Product = { ...product, id };
    this.products.set(id, newProduct);
    return newProduct;
  }
  
  async updateProduct(id: number, updates: Partial<InsertProduct>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    
    const updatedProduct = { ...product, ...updates };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }
  
  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }
  
  // Customers
  async getCustomers(): Promise<Customer[]> {
    return Array.from(this.customers.values());
  }
  
  async getCustomer(id: number): Promise<Customer | undefined> {
    return this.customers.get(id);
  }
  
  async createCustomer(customer: InsertCustomer): Promise<Customer> {
    const id = this.customerIdCounter++;
    const newCustomer: Customer = { ...customer, id };
    this.customers.set(id, newCustomer);
    return newCustomer;
  }
  
  // Invoices
  async getInvoices(): Promise<Invoice[]> {
    return Array.from(this.invoices.values());
  }
  
  async getInvoice(id: number): Promise<Invoice | undefined> {
    return this.invoices.get(id);
  }
  
  async createInvoice(invoice: InsertInvoice): Promise<Invoice> {
    const id = this.invoiceIdCounter++;
    const newInvoice: Invoice = { 
      ...invoice, 
      id,
      createdAt: new Date()
    };
    this.invoices.set(id, newInvoice);
    return newInvoice;
  }
  
  // Invoice Items
  async getInvoiceItems(invoiceId: number): Promise<InvoiceItem[]> {
    return Array.from(this.invoiceItems.values()).filter(
      (item) => item.invoiceId === invoiceId
    );
  }
  
  async createInvoiceItem(item: InsertInvoiceItem): Promise<InvoiceItem> {
    const id = this.invoiceItemIdCounter++;
    const newItem: InvoiceItem = { ...item, id };
    this.invoiceItems.set(id, newItem);
    
    // Update stock quantity
    const product = this.products.get(item.productId);
    if (product) {
      const updatedStock = product.stockQuantity - item.quantity;
      this.updateProduct(product.id, {
        stockQuantity: updatedStock >= 0 ? updatedStock : 0
      });
    }
    
    return newItem;
  }
  
  // For reporting
  async getPopularProducts(limit: number): Promise<Product[]> {
    return Array.from(this.products.values())
      .filter(product => product.isPopular)
      .slice(0, limit);
  }
  
  async getRecentSales(limit: number): Promise<Invoice[]> {
    return Array.from(this.invoices.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
