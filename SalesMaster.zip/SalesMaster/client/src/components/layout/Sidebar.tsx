import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  ShoppingCart,
  Package,
  History,
  BarChartBig,
  Settings,
  User
} from "lucide-react";

export function Sidebar() {
  const [location] = useLocation();

  const menuItems = [
    { path: "/", label: "نقطة البيع", icon: <ShoppingCart className="w-6 h-6" /> },
    { path: "/inventory", label: "المخزون", icon: <Package className="w-6 h-6" /> },
    { path: "/transactions", label: "المعاملات", icon: <History className="w-6 h-6" /> },
    { path: "/reports", label: "التقارير", icon: <BarChartBig className="w-6 h-6" /> },
    { path: "/settings", label: "الإعدادات", icon: <Settings className="w-6 h-6" /> },
  ];

  return (
    <aside className="bg-gray-900 text-white w-20 md:w-64 flex flex-col shrink-0">
      {/* App Logo */}
      <div className="p-4 flex items-center justify-center md:justify-start">
        <ShoppingCart className="h-6 w-6 text-primary" />
        <span className="hidden md:block mr-3 text-xl font-bold">نظام المبيعات</span>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 mt-6">
        <ul>
          {menuItems.map((item) => (
            <li key={item.path} className="mb-2">
              <Link 
                href={item.path} 
                className={cn(
                  "flex items-center px-4 py-3 hover:bg-gray-800",
                  location === item.path ? "bg-primary text-white" : "text-gray-300"
                )}
              >
                <div className="w-6 text-center">{item.icon}</div>
                <span className="hidden md:block mr-3">{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      {/* User Info */}
      <div className="p-4 border-t border-gray-700 text-sm hidden md:block">
        <div className="flex items-center">
          <User className="h-6 w-6 text-gray-400" />
          <div className="mr-3">
            <p className="font-medium">أحمد محمد</p>
            <p className="text-gray-400 text-xs">مدير النظام</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
