import { useState } from "react";
import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BarcodeScanner } from "@/components/pos/BarcodeScanner";

interface HeaderProps {
  title: string;
  onSearch?: (query: string) => void;
  showBarcodeScanButton?: boolean;
  onBarcodeScanned?: (barcode: string) => void;
}

export function Header({ 
  title, 
  onSearch,
  showBarcodeScanButton = false,
  onBarcodeScanned
}: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) {
      onSearch(searchQuery);
    }
  };
  
  const handleBarcodeScanned = (barcode: string) => {
    setIsScannerOpen(false);
    if (onBarcodeScanned) {
      onBarcodeScanned(barcode);
    }
  };
  
  return (
    <header className="bg-white shadow-sm">
      <div className="flex items-center justify-between px-6 py-3">
        <h1 className="text-xl font-bold">{title}</h1>
        <div className="flex items-center gap-4">
          {onSearch && (
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="بحث عن منتج..."
                className="bg-gray-100 rounded-lg px-4 py-2 w-64 pl-10 focus:outline-none focus:ring-2 focus:ring-primary"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-500" />
            </form>
          )}
          
          {showBarcodeScanButton && (
            <Button
              onClick={() => setIsScannerOpen(true)}
              className="flex items-center"
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-5 w-5 mr-2" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={2} 
                  d="M4 7V5a1 1 0 011-1h2M4 17v2a1 1 0 001 1h2m12-14v2a1 1 0 01-1 1h-2m0 12v2a1 1 0 001 1h2" 
                />
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={2} 
                  d="M7 4v16M12 4v16M17 4v16" 
                />
              </svg>
              مسح الباركود
            </Button>
          )}
        </div>
      </div>
      
      {isScannerOpen && (
        <BarcodeScanner 
          isOpen={isScannerOpen}
          onClose={() => setIsScannerOpen(false)}
          onBarcodeScanned={handleBarcodeScanned}
        />
      )}
    </header>
  );
}
