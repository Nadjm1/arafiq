import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Invoice, Product } from "@shared/schema";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Printer, Download } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function SalesReport() {
  const [selectedPeriod, setSelectedPeriod] = useState<"daily" | "weekly" | "monthly">("daily");
  
  // Get recent sales
  const { data: recentSales, isLoading: isSalesLoading } = useQuery<Invoice[]>({
    queryKey: ["/api/invoices/recent"],
  });

  // Get popular products
  const { data: popularProducts, isLoading: isProductsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products/popular"],
  });
  
  // Format data for charts
  const salesData = recentSales?.map(sale => ({
    date: new Date(sale.createdAt).toLocaleDateString("ar"),
    amount: Number(sale.total)
  })) || [];
  
  const productData = popularProducts?.map(product => ({
    name: product.name,
    stock: product.stockQuantity,
    price: Number(product.price)
  })) || [];
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">تقارير المبيعات</h2>
        <div className="flex space-x-2 space-x-reverse">
          <Button variant="outline" size="sm">
            <Printer className="ml-2 h-4 w-4" />
            طباعة
          </Button>
          <Button variant="outline" size="sm">
            <Download className="ml-2 h-4 w-4" />
            تصدير
          </Button>
        </div>
      </div>
      
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              إجمالي المبيعات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {recentSales
                ? recentSales.reduce((sum, sale) => sum + Number(sale.total), 0).toLocaleString()
                : "0"} ر.س
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              عدد المعاملات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {recentSales?.length || 0}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              متوسط قيمة الفاتورة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {recentSales && recentSales.length > 0
                ? (recentSales.reduce((sum, sale) => sum + Number(sale.total), 0) / recentSales.length).toLocaleString()
                : "0"} ر.س
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Charts & Tables */}
      <Tabs defaultValue="sales" className="space-y-4">
        <TabsList>
          <TabsTrigger value="sales">المبيعات</TabsTrigger>
          <TabsTrigger value="products">المنتجات</TabsTrigger>
        </TabsList>
        
        <TabsContent value="sales" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">إحصائيات المبيعات</h3>
            <div className="flex space-x-1 space-x-reverse">
              <Button 
                variant={selectedPeriod === "daily" ? "default" : "outline"} 
                size="sm"
                onClick={() => setSelectedPeriod("daily")}
              >
                يومي
              </Button>
              <Button 
                variant={selectedPeriod === "weekly" ? "default" : "outline"} 
                size="sm"
                onClick={() => setSelectedPeriod("weekly")}
              >
                أسبوعي
              </Button>
              <Button 
                variant={selectedPeriod === "monthly" ? "default" : "outline"} 
                size="sm"
                onClick={() => setSelectedPeriod("monthly")}
              >
                شهري
              </Button>
            </div>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>تحليل المبيعات</CardTitle>
              <CardDescription>
                {selectedPeriod === "daily" && "مبيعات اليوم"}
                {selectedPeriod === "weekly" && "مبيعات الأسبوع"}
                {selectedPeriod === "monthly" && "مبيعات الشهر"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                {isSalesLoading ? (
                  <div className="flex items-center justify-center h-full">
                    جاري التحميل...
                  </div>
                ) : salesData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="amount" name="المبيعات" fill="hsl(var(--chart-1))" />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    لا توجد بيانات للعرض
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>آخر المعاملات</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>رقم الفاتورة</TableHead>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>طريقة الدفع</TableHead>
                    <TableHead>الإجمالي</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isSalesLoading ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center">
                        جاري التحميل...
                      </TableCell>
                    </TableRow>
                  ) : recentSales && recentSales.length > 0 ? (
                    recentSales.map((sale) => (
                      <TableRow key={sale.id}>
                        <TableCell>{sale.id}</TableCell>
                        <TableCell>
                          {new Date(sale.createdAt).toLocaleDateString("ar")}
                        </TableCell>
                        <TableCell>
                          {sale.paymentMethod === "cash" ? "نقدي" : "بطاقة"}
                        </TableCell>
                        <TableCell>{Number(sale.total).toLocaleString()} ر.س</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center">
                        لا توجد معاملات
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="products" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>المنتجات الأكثر مبيعاً</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                {isProductsLoading ? (
                  <div className="flex items-center justify-center h-full">
                    جاري التحميل...
                  </div>
                ) : productData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={productData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="stock" name="المخزون" fill="hsl(var(--chart-2))" />
                      <Bar dataKey="price" name="السعر" fill="hsl(var(--chart-3))" />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    لا توجد بيانات للعرض
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>المنتجات منخفضة المخزون</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>اسم المنتج</TableHead>
                    <TableHead>رمز المنتج</TableHead>
                    <TableHead>السعر</TableHead>
                    <TableHead>المخزون</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isProductsLoading ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center">
                        جاري التحميل...
                      </TableCell>
                    </TableRow>
                  ) : popularProducts && popularProducts.length > 0 ? (
                    popularProducts
                      .filter(product => product.stockQuantity <= 5)
                      .map((product) => (
                        <TableRow key={product.id}>
                          <TableCell>{product.name}</TableCell>
                          <TableCell>{product.sku}</TableCell>
                          <TableCell>
                            {Number(product.price).toLocaleString()} ر.س
                          </TableCell>
                          <TableCell className="text-destructive font-bold">
                            {product.stockQuantity}
                          </TableCell>
                        </TableRow>
                      ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center">
                        لا توجد منتجات منخفضة المخزون
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
