import { useState, useEffect, ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { CartItem, Customer } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useInvoice } from "@/hooks/useInvoice";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { CreditCard, Printer, Save, Plus, BanknoteIcon } from "lucide-react";

interface CheckoutPanelProps {
  cartItems: CartItem[];
  itemCount: number;
  subtotal: number;
  taxAmount: number;
  total: number;
  onCheckout: () => void;
  invoiceContent: ReactNode;
}

export function CheckoutPanel({
  cartItems,
  itemCount,
  subtotal,
  taxAmount,
  total,
  onCheckout,
  invoiceContent
}: CheckoutPanelProps) {
  const [customerId, setCustomerId] = useState<number | null>(1); // Default to cash customer
  const [discount, setDiscount] = useState<number>(0);
  const [discountType, setDiscountType] = useState<"amount" | "percentage">("amount");
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "card">("cash");
  const [amountReceived, setAmountReceived] = useState<string>("");
  const [change, setChange] = useState<number>(0);
  
  const { toast } = useToast();
  const { createAndPrintInvoice, isPrinting, printRef, handlePrint } = useInvoice();
  
  // Fetch customers
  const { data: customers } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });
  
  // Calculate final total after discount
  const calculatedDiscount = discountType === "percentage" 
    ? (subtotal * discount) / 100 
    : discount;
  
  const finalTotal = total - calculatedDiscount;
  
  // Update change amount when received amount changes
  useEffect(() => {
    const received = parseFloat(amountReceived);
    if (!isNaN(received) && received >= finalTotal) {
      setChange(received - finalTotal);
    } else {
      setChange(0);
    }
  }, [amountReceived, finalTotal]);
  
  // Update received amount when total changes (for a better UX)
  useEffect(() => {
    if (finalTotal > 0) {
      // Round up to nearest 10
      const roundedAmount = Math.ceil(finalTotal / 10) * 10;
      setAmountReceived(roundedAmount.toString());
    }
  }, [finalTotal]);
  
  const handleCheckout = async () => {
    if (cartItems.length === 0) {
      toast({
        title: "السلة فارغة",
        description: "لا يمكن إتمام عملية الشراء بدون منتجات",
        variant: "destructive"
      });
      return;
    }
    
    if (paymentMethod === "cash" && (parseFloat(amountReceived) < finalTotal)) {
      toast({
        title: "المبلغ المستلم غير كافي",
        description: "يجب أن يكون المبلغ المستلم أكبر من أو يساوي المبلغ الإجمالي",
        variant: "destructive"
      });
      return;
    }
    
    const result = await createAndPrintInvoice(
      customerId,
      cartItems,
      subtotal,
      taxAmount,
      calculatedDiscount,
      finalTotal,
      parseFloat(amountReceived),
      change,
      paymentMethod
    );
    
    if (result) {
      handlePrint();
      onCheckout();
    }
  };
  
  const handleDiscountChange = (value: string) => {
    const parsedValue = parseFloat(value);
    if (!isNaN(parsedValue) && parsedValue >= 0) {
      // If percentage, cap at 100%
      if (discountType === "percentage" && parsedValue > 100) {
        setDiscount(100);
      } else {
        setDiscount(parsedValue);
      }
    } else {
      setDiscount(0);
    }
  };
  
  return (
    <div className="flex flex-col h-full">
      <div className="p-6 border-b border-gray-200">
        <h2 className="font-bold text-xl mb-4">ملخص الفاتورة</h2>
        
        {/* Customer Info */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <label className="font-medium">العميل</label>
            <Button variant="link" className="h-auto p-0">
              <Plus className="h-4 w-4 mr-1" />
              عميل جديد
            </Button>
          </div>
          <Select
            value={customerId?.toString() || "1"}
            onValueChange={(value) => setCustomerId(parseInt(value))}
          >
            <SelectTrigger>
              <SelectValue placeholder="اختر العميل" />
            </SelectTrigger>
            <SelectContent>
              {customers?.map((customer) => (
                <SelectItem key={customer.id} value={customer.id.toString()}>
                  {customer.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {/* Summary */}
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between mb-2">
              <span className="text-gray-600">عدد المنتجات</span>
              <span className="font-medium">{itemCount}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-gray-600">المجموع الفرعي</span>
              <span className="font-medium">{subtotal.toLocaleString()} ر.س</span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-gray-600">الضريبة (15%)</span>
              <span className="font-medium">{taxAmount.toLocaleString()} ر.س</span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-gray-600">الخصم</span>
              <div className="flex items-center">
                <Input
                  type="text"
                  value={discount}
                  onChange={(e) => handleDiscountChange(e.target.value)}
                  className="w-16 h-8 text-center ml-2"
                />
                <Select
                  value={discountType}
                  onValueChange={(value) => setDiscountType(value as "amount" | "percentage")}
                >
                  <SelectTrigger className="h-8 w-20">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="amount">ر.س</SelectItem>
                    <SelectItem value="percentage">%</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Separator className="my-3" />
            <div className="flex justify-between text-lg font-bold">
              <span>الإجمالي</span>
              <span className="text-primary-dark">{finalTotal.toLocaleString()} ر.س</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Payment Options */}
      <div className="p-6 border-b border-gray-200">
        <h3 className="font-bold mb-3">طريقة الدفع</h3>
        <div className="grid grid-cols-2 gap-3 mb-4">
          <Button
            variant={paymentMethod === "cash" ? "default" : "outline"}
            className="h-12 justify-center"
            onClick={() => setPaymentMethod("cash")}
          >
            <BanknoteIcon className="h-5 w-5 mr-2" />
            نقدي
          </Button>
          <Button
            variant={paymentMethod === "card" ? "default" : "outline"}
            className="h-12 justify-center"
            onClick={() => setPaymentMethod("card")}
          >
            <CreditCard className="h-5 w-5 mr-2" />
            بطاقة
          </Button>
        </div>
        
        {/* Cash Payment Form */}
        {paymentMethod === "cash" && (
          <div>
            <div className="mb-3">
              <label className="block text-gray-600 mb-1">المبلغ المستلم</label>
              <Input
                type="text"
                value={amountReceived}
                onChange={(e) => setAmountReceived(e.target.value)}
                placeholder="أدخل المبلغ"
              />
            </div>
            <div className="mb-3">
              <label className="block text-gray-600 mb-1">المبلغ المتبقي</label>
              <Input
                type="text"
                readOnly
                className="bg-gray-50"
                value={`${change.toLocaleString()} ر.س`}
              />
            </div>
          </div>
        )}
      </div>
      
      {/* Action Buttons */}
      <div className="mt-auto p-6">
        <Button
          className="w-full mb-3 bg-destructive hover:bg-destructive/90"
          size="lg"
          onClick={handleCheckout}
          disabled={isPrinting || cartItems.length === 0}
        >
          <Printer className="mr-2 h-5 w-5" />
          إتمام البيع وطباعة الفاتورة
        </Button>
        <Button
          variant="outline"
          className="w-full"
          size="lg"
          disabled={cartItems.length === 0}
        >
          <Save className="mr-2 h-5 w-5" />
          حفظ كمسودة
        </Button>
      </div>
      
      {/* Hidden Invoice for Printing */}
      <div style={{ display: "none" }}>
        <div ref={printRef} className="p-8 bg-white">
          {invoiceContent}
        </div>
      </div>
    </div>
  );
}
