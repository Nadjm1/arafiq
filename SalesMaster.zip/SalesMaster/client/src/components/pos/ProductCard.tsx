import { Product } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const isLowStock = product.stockQuantity <= 5;
  
  return (
    <Card 
      className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
      onClick={() => onAddToCart(product)}
    >
      <div className="h-32 bg-gray-200 relative">
        {/* Product placeholder */}
        <Badge 
          className={cn(
            "absolute bottom-0 right-0 rounded-tl-md rounded-br-none",
            isLowStock ? "bg-destructive hover:bg-destructive" : "bg-primary hover:bg-primary"
          )}
        >
          متوفر: {product.stockQuantity}
        </Badge>
      </div>
      <CardContent className="p-3">
        <h3 className="font-medium truncate">{product.name}</h3>
        <div className="flex justify-between items-center mt-2">
          <span className="font-bold text-primary-dark">{Number(product.price).toLocaleString()} ر.س</span>
          <Button
            size="icon"
            variant="ghost"
            className="bg-gray-100 hover:bg-gray-200 w-8 h-8 rounded-full"
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart(product);
            }}
          >
            <Plus className="h-4 w-4 text-primary" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
