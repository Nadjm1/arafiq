import { useState, useEffect, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import { useBarcodeScanner } from "@/hooks/useBarcodeScanner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertTriangle, Camera, Info } from "lucide-react";

interface BarcodeScannerProps {
  isOpen: boolean;
  onClose: () => void;
  onBarcodeScanned: (barcode: string) => void;
}

export function BarcodeScanner({ isOpen, onClose, onBarcodeScanned }: BarcodeScannerProps) {
  const [manualBarcode, setManualBarcode] = useState("");
  const { toast } = useToast();
  const scannerRef = useRef<HTMLDivElement>(null);
  
  const { 
    initializeScanner, 
    isInitialized,
    error, 
    onDetected 
  } = useBarcodeScanner();
  
  // Initialize scanner when the modal opens
  useEffect(() => {
    if (isOpen && scannerRef.current) {
      const cleanup = initializeScanner(scannerRef.current);
      return cleanup;
    }
  }, [isOpen, initializeScanner]);
  
  // Set up detection handler
  useEffect(() => {
    if (isInitialized) {
      const cleanup = onDetected((barcode) => {
        onBarcodeScanned(barcode);
        toast({
          title: "تم المسح بنجاح",
          description: `تم مسح الباركود: ${barcode}`
        });
      });
      
      return cleanup;
    }
  }, [isInitialized, onDetected, onBarcodeScanned, toast]);
  
  const handleManualSearch = () => {
    if (!manualBarcode.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال رمز المنتج",
        variant: "destructive"
      });
      return;
    }
    
    onBarcodeScanned(manualBarcode);
    setManualBarcode("");
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleManualSearch();
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Camera className="h-5 w-5" />
            مسح الباركود
          </DialogTitle>
        </DialogHeader>
        
        {/* Scanner View */}
        <div className="bg-gray-900 w-full h-64 rounded-lg mb-4 overflow-hidden relative">
          <div ref={scannerRef} className="absolute inset-0">
            {error && (
              <div className="flex items-center justify-center h-full">
                <div className="text-white text-center">
                  <AlertTriangle className="h-10 w-10 text-red-500 mb-2 mx-auto" />
                  <p className="text-gray-400">{error}</p>
                </div>
              </div>
            )}
            {!isInitialized && !error && (
              <div className="flex items-center justify-center h-full">
                <div className="text-white text-center">
                  <Camera className="h-10 w-10 text-gray-400 mb-2 mx-auto" />
                  <p className="text-gray-400">جارٍ تشغيل الكاميرا...</p>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Scan Instructions */}
        <div className="bg-primary/10 border border-primary/20 rounded-lg p-4 text-center mb-4">
          <p className="text-primary-foreground flex items-center justify-center gap-2">
            <Info className="h-5 w-5" />
            قم بتوجيه الكاميرا إلى الباركود للمسح التلقائي
          </p>
        </div>
        
        {/* Manual Entry */}
        <form onSubmit={handleSubmit}>
          <div>
            <label className="block text-gray-600 mb-1">
              أو أدخل رمز المنتج يدوياً
            </label>
            <div className="flex">
              <Input
                type="text"
                value={manualBarcode}
                onChange={(e) => setManualBarcode(e.target.value)}
                className="flex-1 rounded-l-none"
              />
              <Button 
                type="submit"
                className="rounded-r-none"
              >
                بحث
              </Button>
            </div>
          </div>
        </form>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="w-full">
            إلغاء
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
