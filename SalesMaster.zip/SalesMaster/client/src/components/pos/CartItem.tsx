import { CartItem as CartItemType } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash, Plus, Minus } from "lucide-react";

interface CartItemProps {
  item: CartItemType;
  onUpdateQuantity: (productId: number, quantity: number) => void;
  onRemove: (productId: number) => void;
}

export function CartItem({ item, onUpdateQuantity, onRemove }: CartItemProps) {
  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newQuantity = parseInt(e.target.value);
    if (!isNaN(newQuantity) && newQuantity > 0) {
      onUpdateQuantity(item.productId, newQuantity);
    }
  };
  
  const increaseQuantity = () => {
    onUpdateQuantity(item.productId, item.quantity + 1);
  };
  
  const decreaseQuantity = () => {
    if (item.quantity > 1) {
      onUpdateQuantity(item.productId, item.quantity - 1);
    }
  };
  
  return (
    <tr className="border-b border-gray-200">
      <td className="py-3 px-4">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-gray-200 rounded flex-shrink-0"></div>
          <div className="mr-3">
            <p className="font-medium">{item.name}</p>
            <p className="text-gray-500 text-xs">#{item.sku}</p>
          </div>
        </div>
      </td>
      <td className="py-3 px-4 text-center">{item.price.toLocaleString()} ر.س</td>
      <td className="py-3 px-4">
        <div className="flex items-center justify-center space-x-1 space-x-reverse">
          <Button 
            variant="outline" 
            size="icon" 
            className="w-8 h-8"
            onClick={decreaseQuantity}
          >
            <Minus className="h-4 w-4" />
          </Button>
          <Input
            type="number"
            value={item.quantity}
            onChange={handleQuantityChange}
            className="w-12 text-center h-8"
            min={1}
          />
          <Button 
            variant="outline" 
            size="icon" 
            className="w-8 h-8"
            onClick={increaseQuantity}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </td>
      <td className="py-3 px-4 text-center font-medium">{item.subtotal.toLocaleString()} ر.س</td>
      <td className="py-3 px-4 text-center">
        <Button 
          variant="ghost" 
          size="icon" 
          className="text-destructive hover:text-destructive hover:bg-destructive/10"
          onClick={() => onRemove(item.productId)}
        >
          <Trash className="h-4 w-4" />
        </Button>
      </td>
    </tr>
  );
}
