import { useState, useRef, useCallback, useEffect } from "react";
import Quagga from "@ericblade/quagga2";

interface BarcodeResult {
  codeResult: {
    code: string;
  };
}

export function useBarcodeScanner() {
  const [isInitialized, setIsInitialized] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scannerRef = useRef<HTMLDivElement | null>(null);

  const initializeScanner = useCallback((element: HTMLDivElement) => {
    scannerRef.current = element;
    
    if (!element) {
      setError("Camera element not found");
      return;
    }
    
    Quagga.init(
      {
        inputStream: {
          type: "LiveStream",
          constraints: {
            width: { min: 450 },
            height: { min: 300 },
            facingMode: "environment",
            aspectRatio: { min: 1, max: 2 }
          },
          target: element
        },
        locator: {
          patchSize: "medium",
          halfSample: true
        },
        numOfWorkers: 2,
        frequency: 10,
        decoder: {
          readers: ["ean_reader", "ean_8_reader", "code_128_reader"]
        },
        locate: true
      },
      (err) => {
        if (err) {
          setError(`Error initializing scanner: ${err.message || err}`);
          return;
        }
        
        setIsInitialized(true);
        Quagga.start();
      }
    );
    
    return () => {
      if (isInitialized) {
        Quagga.stop();
        setIsInitialized(false);
      }
    };
  }, [isInitialized]);
  
  const onDetected = useCallback((callback: (barcode: string) => void) => {
    const handler = (result: BarcodeResult) => {
      if (result.codeResult && result.codeResult.code) {
        Quagga.offDetected(handler);
        callback(result.codeResult.code);
      }
    };
    
    if (isInitialized) {
      Quagga.onDetected(handler);
    }
    
    return () => {
      if (isInitialized) {
        Quagga.offDetected(handler);
      }
    };
  }, [isInitialized]);
  
  // Clean up scanner on unmount
  useEffect(() => {
    return () => {
      if (isInitialized) {
        Quagga.stop();
      }
    };
  }, [isInitialized]);

  return {
    initializeScanner,
    isInitialized,
    error,
    onDetected
  };
}
