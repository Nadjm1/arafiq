import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Product, InsertProduct } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useInventory() {
  const { toast } = useToast();

  // Get all products
  const {
    data: products,
    isLoading: isLoadingProducts,
    error: productsError
  } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  // Get popular products
  const {
    data: popularProducts,
    isLoading: isLoadingPopular,
    error: popularError
  } = useQuery<Product[]>({
    queryKey: ["/api/products/popular"],
  });

  // Add product
  const addProductMutation = useMutation({
    mutationFn: async (product: InsertProduct) => {
      const res = await apiRequest("POST", "/api/products", product);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "تم إضافة المنتج",
        description: "تمت إضافة المنتج بنجاح"
      });
    },
    onError: (error) => {
      toast({
        title: "حدث خطأ",
        description: error.message || "فشل إضافة المنتج",
        variant: "destructive"
      });
    }
  });

  // Update product
  const updateProductMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertProduct> }) => {
      const res = await apiRequest("PUT", `/api/products/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "تم تحديث المنتج",
        description: "تم تحديث المنتج بنجاح"
      });
    },
    onError: (error) => {
      toast({
        title: "حدث خطأ",
        description: error.message || "فشل تحديث المنتج",
        variant: "destructive"
      });
    }
  });

  // Delete product
  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/products/${id}`);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "تم حذف المنتج",
        description: "تم حذف المنتج بنجاح"
      });
    },
    onError: (error) => {
      toast({
        title: "حدث خطأ",
        description: error.message || "فشل حذف المنتج",
        variant: "destructive"
      });
    }
  });

  // Get product by barcode
  const getProductByBarcode = async (barcode: string): Promise<Product | null> => {
    try {
      const res = await fetch(`/api/products/barcode/${barcode}`, {
        credentials: "include"
      });
      
      if (res.ok) {
        return await res.json();
      }
      
      if (res.status === 404) {
        toast({
          title: "الباركود غير موجود",
          description: "لم يتم العثور على منتج بهذا الباركود",
          variant: "destructive"
        });
      } else {
        throw new Error(`${res.status}: ${res.statusText}`);
      }
    } catch (error) {
      toast({
        title: "حدث خطأ",
        description: error.message || "فشل البحث عن المنتج",
        variant: "destructive"
      });
    }
    
    return null;
  };

  return {
    products,
    isLoadingProducts,
    productsError,
    popularProducts,
    isLoadingPopular,
    popularError,
    addProduct: addProductMutation.mutate,
    updateProduct: updateProductMutation.mutate,
    deleteProduct: deleteProductMutation.mutate,
    getProductByBarcode,
    isAddingProduct: addProductMutation.isPending,
    isUpdatingProduct: updateProductMutation.isPending,
    isDeletingProduct: deleteProductMutation.isPending
  };
}
