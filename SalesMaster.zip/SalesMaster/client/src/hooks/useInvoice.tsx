import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { CartItem, InsertInvoice, Invoice, InvoiceItem } from "@shared/schema";
import { useRef } from "react";
import { useReactToPrint } from "react-to-print";

interface InvoiceData {
  invoice: InsertInvoice;
  items: Array<{
    productId: number;
    quantity: number;
    unitPrice: number;
    subtotal: number;
  }>;
}

interface InvoiceResponse {
  invoice: Invoice;
  items: InvoiceItem[];
}

export function useInvoice() {
  const { toast } = useToast();
  const printRef = useRef<HTMLDivElement>(null);

  const createInvoiceMutation = useMutation<InvoiceResponse, Error, InvoiceData>({
    mutationFn: async (data) => {
      const res = await apiRequest("POST", "/api/invoices", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products/popular"] });
      toast({
        title: "تم إنشاء الفاتورة",
        description: "تم إنشاء الفاتورة بنجاح وتحديث المخزون",
      });
    },
    onError: (error) => {
      toast({
        title: "فشل إنشاء الفاتورة",
        description: error.message || "حدث خطأ أثناء إنشاء الفاتورة",
        variant: "destructive",
      });
    },
  });

  const createAndPrintInvoice = async (
    customerId: number | null,
    cartItems: CartItem[],
    subtotal: number,
    taxAmount: number,
    discount: number,
    total: number,
    amountReceived: number | null,
    change: number | null,
    paymentMethod: string
  ) => {
    if (cartItems.length === 0) {
      toast({
        title: "لا يمكن إنشاء فاتورة فارغة",
        description: "يرجى إضافة منتجات إلى السلة أولاً",
        variant: "destructive",
      });
      return null;
    }

    const invoiceData: InvoiceData = {
      invoice: {
        customerId: customerId || undefined,
        subtotal: subtotal.toString(),
        taxAmount: taxAmount.toString(),
        discount: discount.toString(),
        total: total.toString(),
        amountReceived: amountReceived ? amountReceived.toString() : undefined,
        change: change ? change.toString() : undefined,
        paymentMethod,
      },
      items: cartItems.map((item) => ({
        productId: item.productId,
        quantity: item.quantity,
        unitPrice: item.price,
        subtotal: item.subtotal,
      })),
    };

    try {
      const result = await createInvoiceMutation.mutateAsync(invoiceData);
      return result;
    } catch (error) {
      return null;
    }
  };

  const handlePrint = useReactToPrint({
    content: () => printRef.current,
    documentTitle: "فاتورة مبيعات",
    onAfterPrint: () => {
      toast({
        title: "تمت الطباعة",
        description: "تمت طباعة الفاتورة بنجاح",
      });
    },
  });

  return {
    createAndPrintInvoice,
    isPrinting: createInvoiceMutation.isPending,
    printRef,
    handlePrint,
  };
}
