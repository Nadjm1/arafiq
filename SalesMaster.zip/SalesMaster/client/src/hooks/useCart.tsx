import { useState, useCallback, useMemo } from "react";
import { CartItem, Product } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useCart() {
  const [items, setItems] = useState<CartItem[]>([]);
  const { toast } = useToast();
  
  const addItem = useCallback((product: Product, quantity = 1) => {
    setItems(currentItems => {
      // Check if product is already in cart
      const existingItemIndex = currentItems.findIndex(item => item.productId === product.id);
      
      if (existingItemIndex >= 0) {
        // Update quantity if product already exists
        const updatedItems = [...currentItems];
        const newQuantity = currentItems[existingItemIndex].quantity + quantity;
        
        // Don't allow adding more than available stock
        if (newQuantity > product.stockQuantity) {
          toast({
            title: "الكمية غير متوفرة",
            description: `المتوفر فقط ${product.stockQuantity} قطعة`,
            variant: "destructive"
          });
          return currentItems;
        }
        
        updatedItems[existingItemIndex] = {
          ...updatedItems[existingItemIndex],
          quantity: newQuantity,
          subtotal: Number(product.price) * newQuantity
        };
        return updatedItems;
      } else {
        // Add new product to cart
        if (quantity > product.stockQuantity) {
          toast({
            title: "الكمية غير متوفرة",
            description: `المتوفر فقط ${product.stockQuantity} قطعة`,
            variant: "destructive"
          });
          return currentItems;
        }
        
        const newItem: CartItem = {
          productId: product.id,
          name: product.name,
          sku: product.sku,
          price: Number(product.price),
          quantity,
          subtotal: Number(product.price) * quantity
        };
        return [...currentItems, newItem];
      }
    });
  }, [toast]);
  
  const updateQuantity = useCallback((productId: number, quantity: number) => {
    setItems(currentItems => {
      return currentItems.map(item => {
        if (item.productId === productId) {
          return {
            ...item,
            quantity,
            subtotal: item.price * quantity
          };
        }
        return item;
      });
    });
  }, []);
  
  const removeItem = useCallback((productId: number) => {
    setItems(currentItems => currentItems.filter(item => item.productId !== productId));
  }, []);
  
  const clearCart = useCallback(() => {
    setItems([]);
  }, []);
  
  // Calculate totals
  const totals = useMemo(() => {
    const subtotal = items.reduce((sum, item) => sum + item.subtotal, 0);
    const taxRate = 0.15; // 15% tax
    const taxAmount = subtotal * taxRate;
    const total = subtotal + taxAmount;
    
    return {
      itemCount: items.length,
      subtotal,
      taxRate,
      taxAmount,
      total
    };
  }, [items]);
  
  return {
    items,
    addItem,
    updateQuantity,
    removeItem,
    clearCart,
    totals
  };
}
