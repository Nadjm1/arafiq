import { useState } from "react";
import { Header } from "@/components/layout/Header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Save, Store, Printer, Receipt, UserCircle, Coins, Database } from "lucide-react";

export default function Settings() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("general");
  
  // General settings
  const [storeName, setStoreName] = useState("نظام المبيعات");
  const [vatNumber, setVatNumber] = useState("123456789012345");
  const [storePhone, setStorePhone] = useState("0512345678");
  const [storeAddress, setStoreAddress] = useState("شارع الرياض، المملكة العربية السعودية");
  
  // Invoice settings
  const [invoicePrefix, setInvoicePrefix] = useState("INV-");
  const [showVatOnInvoice, setShowVatOnInvoice] = useState(true);
  const [showStoreLogo, setShowStoreLogo] = useState(true);
  const [receiptWidth, setReceiptWidth] = useState("80");
  const [printAutomatically, setPrintAutomatically] = useState(true);
  
  // User settings
  const [userName, setUserName] = useState("أحمد محمد");
  const [userEmail, setUserEmail] = useState("ahmed@example.com");
  const [userRole, setUserRole] = useState("admin");
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  
  // Tax settings
  const [taxRate, setTaxRate] = useState("15");
  const [taxIncluded, setTaxIncluded] = useState(false);
  
  // Backup settings
  const [autoBackup, setAutoBackup] = useState(true);
  const [backupFrequency, setBackupFrequency] = useState("daily");
  
  const saveSettings = () => {
    // In a real application, this would save settings to the server
    toast({
      title: "تم حفظ الإعدادات",
      description: "تم حفظ الإعدادات بنجاح",
    });
  };
  
  return (
    <>
      <Header title="الإعدادات" />
      
      <div className="flex-1 p-6 overflow-auto">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-5 h-auto">
            <TabsTrigger value="general" className="flex items-center gap-2 py-2.5">
              <Store className="h-4 w-4" />
              <span className="hidden md:inline">عام</span>
            </TabsTrigger>
            <TabsTrigger value="invoice" className="flex items-center gap-2 py-2.5">
              <Receipt className="h-4 w-4" />
              <span className="hidden md:inline">الفواتير</span>
            </TabsTrigger>
            <TabsTrigger value="user" className="flex items-center gap-2 py-2.5">
              <UserCircle className="h-4 w-4" />
              <span className="hidden md:inline">المستخدم</span>
            </TabsTrigger>
            <TabsTrigger value="tax" className="flex items-center gap-2 py-2.5">
              <Coins className="h-4 w-4" />
              <span className="hidden md:inline">الضرائب</span>
            </TabsTrigger>
            <TabsTrigger value="backup" className="flex items-center gap-2 py-2.5">
              <Database className="h-4 w-4" />
              <span className="hidden md:inline">النسخ الاحتياطي</span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="general">
            <Card>
              <CardHeader>
                <CardTitle>إعدادات عامة</CardTitle>
                <CardDescription>
                  إعدادات المتجر الأساسية والمعلومات العامة
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="store-name">اسم المتجر</Label>
                    <Input 
                      id="store-name" 
                      value={storeName} 
                      onChange={(e) => setStoreName(e.target.value)} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="vat-number">الرقم الضريبي</Label>
                    <Input 
                      id="vat-number" 
                      value={vatNumber} 
                      onChange={(e) => setVatNumber(e.target.value)} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="store-phone">رقم الهاتف</Label>
                    <Input 
                      id="store-phone" 
                      value={storePhone} 
                      onChange={(e) => setStorePhone(e.target.value)} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="store-address">العنوان</Label>
                    <Input 
                      id="store-address" 
                      value={storeAddress} 
                      onChange={(e) => setStoreAddress(e.target.value)} 
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>شعار المتجر</Label>
                  <div className="flex items-center gap-4">
                    <div className="h-20 w-20 border rounded flex items-center justify-center bg-gray-50">
                      <Store className="h-10 w-10 text-gray-400" />
                    </div>
                    <Button variant="outline">تغيير الشعار</Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button onClick={saveSettings}>
                  <Save className="ml-2 h-4 w-4" />
                  حفظ الإعدادات
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="invoice">
            <Card>
              <CardHeader>
                <CardTitle>إعدادات الفواتير</CardTitle>
                <CardDescription>
                  ضبط طريقة عرض وطباعة الفواتير
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="invoice-prefix">بادئة رقم الفاتورة</Label>
                    <Input 
                      id="invoice-prefix" 
                      value={invoicePrefix} 
                      onChange={(e) => setInvoicePrefix(e.target.value)} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="receipt-width">عرض الإيصال (ملم)</Label>
                    <Input 
                      id="receipt-width" 
                      type="number" 
                      value={receiptWidth} 
                      onChange={(e) => setReceiptWidth(e.target.value)} 
                    />
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="show-vat">إظهار الضريبة على الفاتورة</Label>
                      <p className="text-sm text-muted-foreground">
                        عرض تفاصيل ضريبة القيمة المضافة على الفاتورة
                      </p>
                    </div>
                    <Switch 
                      id="show-vat" 
                      checked={showVatOnInvoice} 
                      onCheckedChange={setShowVatOnInvoice} 
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="show-logo">إظهار شعار المتجر</Label>
                      <p className="text-sm text-muted-foreground">
                        عرض شعار المتجر على الفاتورة المطبوعة
                      </p>
                    </div>
                    <Switch 
                      id="show-logo" 
                      checked={showStoreLogo} 
                      onCheckedChange={setShowStoreLogo} 
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="print-auto">طباعة تلقائية</Label>
                      <p className="text-sm text-muted-foreground">
                        طباعة الفاتورة تلقائياً بعد إتمام عملية البيع
                      </p>
                    </div>
                    <Switch 
                      id="print-auto" 
                      checked={printAutomatically} 
                      onCheckedChange={setPrintAutomatically} 
                    />
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <Label>نموذج الطباعة</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
                      <div className="h-32 w-full bg-gray-100 rounded flex items-center justify-center">
                        <Printer className="h-10 w-10 text-gray-400" />
                      </div>
                      <span>فاتورة كاملة</span>
                    </Button>
                    <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2 border-primary">
                      <div className="h-32 w-full bg-gray-100 rounded flex items-center justify-center">
                        <Receipt className="h-10 w-10 text-gray-400" />
                      </div>
                      <span>إيصال مختصر</span>
                    </Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button onClick={saveSettings}>
                  <Save className="ml-2 h-4 w-4" />
                  حفظ الإعدادات
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="user">
            <Card>
              <CardHeader>
                <CardTitle>إعدادات المستخدم</CardTitle>
                <CardDescription>
                  إدارة معلومات الحساب وتفضيلات المستخدم
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="user-name">اسم المستخدم</Label>
                    <Input 
                      id="user-name" 
                      value={userName} 
                      onChange={(e) => setUserName(e.target.value)} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="user-email">البريد الإلكتروني</Label>
                    <Input 
                      id="user-email" 
                      type="email" 
                      value={userEmail} 
                      onChange={(e) => setUserEmail(e.target.value)} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="user-role">الدور</Label>
                    <Select value={userRole} onValueChange={setUserRole}>
                      <SelectTrigger id="user-role">
                        <SelectValue placeholder="اختر الدور" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="admin">مدير النظام</SelectItem>
                        <SelectItem value="cashier">أمين الصندوق</SelectItem>
                        <SelectItem value="inventory">مدير المخزون</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="user-password">كلمة المرور</Label>
                    <Input 
                      id="user-password" 
                      type="password" 
                      placeholder="••••••••" 
                    />
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="notifications">الإشعارات</Label>
                      <p className="text-sm text-muted-foreground">
                        تلقي إشعارات عند انخفاض المخزون أو إتمام عمليات البيع
                      </p>
                    </div>
                    <Switch 
                      id="notifications" 
                      checked={notificationsEnabled} 
                      onCheckedChange={setNotificationsEnabled} 
                    />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button onClick={saveSettings}>
                  <Save className="ml-2 h-4 w-4" />
                  حفظ الإعدادات
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="tax">
            <Card>
              <CardHeader>
                <CardTitle>إعدادات الضرائب</CardTitle>
                <CardDescription>
                  ضبط نسب وإعدادات الضرائب المطبقة
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="tax-rate">نسبة الضريبة (%)</Label>
                    <Input 
                      id="tax-rate" 
                      type="number" 
                      value={taxRate} 
                      onChange={(e) => setTaxRate(e.target.value)} 
                    />
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="tax-included">الأسعار شاملة الضريبة</Label>
                    <p className="text-sm text-muted-foreground">
                      عند التفعيل، ستكون الأسعار المعروضة شاملة الضريبة
                    </p>
                  </div>
                  <Switch 
                    id="tax-included" 
                    checked={taxIncluded} 
                    onCheckedChange={setTaxIncluded} 
                  />
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button onClick={saveSettings}>
                  <Save className="ml-2 h-4 w-4" />
                  حفظ الإعدادات
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="backup">
            <Card>
              <CardHeader>
                <CardTitle>النسخ الاحتياطي</CardTitle>
                <CardDescription>
                  إعدادات النسخ الاحتياطي واستعادة البيانات
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="auto-backup">نسخ احتياطي تلقائي</Label>
                    <p className="text-sm text-muted-foreground">
                      إنشاء نسخة احتياطية للبيانات بشكل دوري
                    </p>
                  </div>
                  <Switch 
                    id="auto-backup" 
                    checked={autoBackup} 
                    onCheckedChange={setAutoBackup} 
                  />
                </div>
                
                {autoBackup && (
                  <div className="space-y-2">
                    <Label htmlFor="backup-frequency">تكرار النسخ الاحتياطي</Label>
                    <Select value={backupFrequency} onValueChange={setBackupFrequency}>
                      <SelectTrigger id="backup-frequency">
                        <SelectValue placeholder="اختر التكرار" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">يومياً</SelectItem>
                        <SelectItem value="weekly">أسبوعياً</SelectItem>
                        <SelectItem value="monthly">شهرياً</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
                
                <Separator />
                
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">إدارة النسخ الاحتياطي</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <Button variant="outline" className="w-full">
                      إنشاء نسخة احتياطية الآن
                    </Button>
                    <Button variant="outline" className="w-full">
                      استعادة من نسخة احتياطية
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">تصدير البيانات</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <Button variant="outline" className="w-full">
                      تصدير المنتجات (Excel)
                    </Button>
                    <Button variant="outline" className="w-full">
                      تصدير المبيعات (Excel)
                    </Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button onClick={saveSettings}>
                  <Save className="ml-2 h-4 w-4" />
                  حفظ الإعدادات
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}
