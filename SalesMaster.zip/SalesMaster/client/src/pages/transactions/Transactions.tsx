import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Header } from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Printer, ArrowDownToLine, Eye } from "lucide-react";
import { Invoice } from "@shared/schema";

export default function Transactions() {
  const [selectedInvoice, setSelectedInvoice] = useState<number | null>(null);
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(false);
  
  const { data: invoices, isLoading } = useQuery<Invoice[]>({
    queryKey: ["/api/invoices"],
  });
  
  const { data: invoiceDetails, isLoading: isInvoiceDetailsLoading } = useQuery({
    queryKey: ["/api/invoices", selectedInvoice],
    enabled: selectedInvoice !== null,
  });
  
  const viewInvoice = (invoiceId: number) => {
    setSelectedInvoice(invoiceId);
    setIsInvoiceModalOpen(true);
  };
  
  return (
    <>
      <Header title="المعاملات" />
      
      <div className="flex-1 p-6 overflow-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                إجمالي المبيعات
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {invoices
                  ? invoices.reduce((sum, invoice) => sum + Number(invoice.total), 0).toLocaleString()
                  : "0"} ر.س
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                عدد المعاملات
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {invoices?.length || 0}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                متوسط قيمة الفاتورة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {invoices && invoices.length > 0
                  ? (invoices.reduce((sum, invoice) => sum + Number(invoice.total), 0) / invoices.length).toLocaleString()
                  : "0"} ر.س
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="all" className="space-y-4">
          <div className="flex justify-between items-center">
            <TabsList>
              <TabsTrigger value="all">جميع المعاملات</TabsTrigger>
              <TabsTrigger value="today">معاملات اليوم</TabsTrigger>
              <TabsTrigger value="week">معاملات الأسبوع</TabsTrigger>
            </TabsList>
            
            <div className="flex space-x-2 space-x-reverse">
              <Button variant="outline" size="sm">
                <ArrowDownToLine className="ml-2 h-4 w-4" />
                تصدير
              </Button>
              <Button variant="outline" size="sm">
                <Printer className="ml-2 h-4 w-4" />
                طباعة
              </Button>
            </div>
          </div>
          
          <TabsContent value="all">
            <Card>
              <CardHeader>
                <CardTitle>جميع المعاملات</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>رقم الفاتورة</TableHead>
                      <TableHead>التاريخ</TableHead>
                      <TableHead>العميل</TableHead>
                      <TableHead>طريقة الدفع</TableHead>
                      <TableHead>المجموع</TableHead>
                      <TableHead>إجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-10">
                          جاري التحميل...
                        </TableCell>
                      </TableRow>
                    ) : invoices && invoices.length > 0 ? (
                      invoices.map((invoice) => (
                        <TableRow key={invoice.id}>
                          <TableCell className="font-medium">{invoice.id}</TableCell>
                          <TableCell>
                            {new Date(invoice.createdAt).toLocaleDateString("ar")}
                          </TableCell>
                          <TableCell>
                            {invoice.customerId ? `عميل #${invoice.customerId}` : "عميل نقدي"}
                          </TableCell>
                          <TableCell>
                            <Badge>
                              {invoice.paymentMethod === "cash" ? "نقدي" : "بطاقة"}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-bold">
                            {Number(invoice.total).toLocaleString()} ر.س
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => viewInvoice(invoice.id)}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-10">
                          لا توجد معاملات
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="today">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-10 text-muted-foreground">
                  معاملات اليوم
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="week">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-10 text-muted-foreground">
                  معاملات الأسبوع
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        {/* Invoice Details Modal */}
        <Dialog open={isInvoiceModalOpen} onOpenChange={setIsInvoiceModalOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>تفاصيل الفاتورة #{selectedInvoice}</DialogTitle>
            </DialogHeader>
            
            {isInvoiceDetailsLoading ? (
              <div className="text-center py-8">جاري تحميل التفاصيل...</div>
            ) : invoiceDetails ? (
              <div>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-muted-foreground">رقم الفاتورة</p>
                    <p className="font-medium">{selectedInvoice}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">التاريخ</p>
                    <p className="font-medium">
                      {invoiceDetails.invoice && new Date(invoiceDetails.invoice.createdAt).toLocaleDateString("ar")}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">العميل</p>
                    <p className="font-medium">
                      {invoiceDetails.invoice && (invoiceDetails.invoice.customerId 
                        ? `عميل #${invoiceDetails.invoice.customerId}` 
                        : "عميل نقدي")}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">طريقة الدفع</p>
                    <p className="font-medium">
                      {invoiceDetails.invoice && (invoiceDetails.invoice.paymentMethod === "cash" 
                        ? "نقدي" 
                        : "بطاقة")}
                    </p>
                  </div>
                </div>
                
                <div className="border rounded-md mb-4">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>المنتج</TableHead>
                        <TableHead className="text-center">السعر</TableHead>
                        <TableHead className="text-center">الكمية</TableHead>
                        <TableHead className="text-center">المجموع</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {invoiceDetails.items && invoiceDetails.items.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell>منتج #{item.productId}</TableCell>
                          <TableCell className="text-center">
                            {Number(item.unitPrice).toLocaleString()} ر.س
                          </TableCell>
                          <TableCell className="text-center">
                            {item.quantity}
                          </TableCell>
                          <TableCell className="text-center font-medium">
                            {Number(item.subtotal).toLocaleString()} ر.س
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">المجموع الفرعي:</span>
                    <span>
                      {invoiceDetails.invoice && Number(invoiceDetails.invoice.subtotal).toLocaleString()} ر.س
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">الضريبة:</span>
                    <span>
                      {invoiceDetails.invoice && Number(invoiceDetails.invoice.taxAmount).toLocaleString()} ر.س
                    </span>
                  </div>
                  {invoiceDetails.invoice && Number(invoiceDetails.invoice.discount) > 0 && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">الخصم:</span>
                      <span className="text-destructive">
                        - {Number(invoiceDetails.invoice.discount).toLocaleString()} ر.س
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between border-t pt-2 font-bold">
                    <span>الإجمالي:</span>
                    <span>
                      {invoiceDetails.invoice && Number(invoiceDetails.invoice.total).toLocaleString()} ر.س
                    </span>
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end space-x-2 space-x-reverse">
                  <Button variant="outline" size="sm" onClick={() => setIsInvoiceModalOpen(false)}>
                    إغلاق
                  </Button>
                  <Button size="sm">
                    <Printer className="ml-2 h-4 w-4" />
                    طباعة الفاتورة
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                لا توجد تفاصيل متاحة
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}
