import { Header } from "@/components/layout/Header";
import { SalesReport } from "@/components/reports/SalesReport";

export default function Reports() {
  return (
    <>
      <Header title="التقارير" />
      
      <div className="flex-1 p-6 overflow-auto">
        <SalesReport />
      </div>
    </>
  );
}
