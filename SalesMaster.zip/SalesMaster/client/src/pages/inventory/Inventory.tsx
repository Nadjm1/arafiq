import { Header } from "@/components/layout/Header";
import { ProductList } from "@/components/inventory/ProductList";
import { useInventory } from "@/hooks/useInventory";

export default function Inventory() {
  const {
    products,
    isLoadingProducts,
    addProduct,
    updateProduct,
    deleteProduct,
    isAddingProduct,
    isUpdatingProduct,
    isDeletingProduct
  } = useInventory();
  
  return (
    <>
      <Header title="إدارة المخزون" onSearch={(query) => console.log(query)} />
      
      <div className="flex-1 p-6 overflow-auto">
        <ProductList
          products={products || []}
          isLoading={isLoadingProducts}
          onAddProduct={addProduct}
          onUpdateProduct={updateProduct}
          onDeleteProduct={deleteProduct}
          isAddingProduct={isAddingProduct}
          isUpdatingProduct={isUpdatingProduct}
          isDeletingProduct={isDeletingProduct}
        />
      </div>
    </>
  );
}
