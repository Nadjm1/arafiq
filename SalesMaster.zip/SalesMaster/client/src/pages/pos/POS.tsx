import { useState, useRef } from "react";
import { Header } from "@/components/layout/Header";
import { CartItem } from "@/components/pos/CartItem";
import { ProductCard } from "@/components/pos/ProductCard";
import { CheckoutPanel } from "@/components/pos/CheckoutPanel";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/useCart";
import { useInventory } from "@/hooks/useInventory";
import { Trash2, RefreshCw } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function POS() {
  const { 
    items, 
    addItem, 
    updateQuantity, 
    removeItem, 
    clearCart, 
    totals 
  } = useCart();
  
  const { 
    popularProducts, 
    isLoadingPopular, 
    getProductByBarcode 
  } = useInventory();
  
  const [searchQuery, setSearchQuery] = useState("");
  
  const handleSearch = (query: string) => {
    setSearchQuery(query);
    // In a real app, we would filter products based on search
  };
  
  const handleBarcodeScanned = async (barcode: string) => {
    const product = await getProductByBarcode(barcode);
    if (product) {
      addItem(product);
    }
  };
  
  const handleProductClick = (product: any) => {
    addItem(product);
  };
  
  // Invoice content for printing
  const invoiceContent = (
    <div className="font-sans">
      <div className="text-center mb-6">
        <h1 className="text-2xl font-bold">نظام المبيعات</h1>
        <p>فاتورة ضريبية مبسطة</p>
        <p>رقم الفاتورة: {Date.now()}</p>
        <p>التاريخ: {new Date().toLocaleDateString("ar")}</p>
      </div>
      
      <div className="mb-6">
        <h2 className="text-lg font-bold mb-2">تفاصيل المنتجات</h2>
        <table className="w-full">
          <thead>
            <tr className="border-b">
              <th className="text-right">المنتج</th>
              <th>السعر</th>
              <th>الكمية</th>
              <th>المجموع</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.productId} className="border-b">
                <td>{item.name}</td>
                <td>{item.price.toLocaleString()} ر.س</td>
                <td>{item.quantity}</td>
                <td>{item.subtotal.toLocaleString()} ر.س</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="border-t pt-2">
        <div className="flex justify-between">
          <span>المجموع الفرعي:</span>
          <span>{totals.subtotal.toLocaleString()} ر.س</span>
        </div>
        <div className="flex justify-between">
          <span>الضريبة (15%):</span>
          <span>{totals.taxAmount.toLocaleString()} ر.س</span>
        </div>
        <div className="flex justify-between font-bold">
          <span>الإجمالي:</span>
          <span>{totals.total.toLocaleString()} ر.س</span>
        </div>
      </div>
      
      <div className="mt-8 text-center text-sm">
        <p>شكراً لزيارتكم</p>
        <p>نظام المبيعات والمخزون</p>
      </div>
    </div>
  );
  
  return (
    <>
      <Header 
        title="نقطة البيع" 
        onSearch={handleSearch}
        showBarcodeScanButton={true}
        onBarcodeScanned={handleBarcodeScanned}
      />
      
      {/* Content Container */}
      <div className="flex-1 overflow-hidden flex">
        {/* Left Panel - Products */}
        <div className="w-2/3 p-6 overflow-auto">
          {/* Cart Items Table */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-4 border-b border-gray-200 flex justify-between items-center">
              <h2 className="font-bold text-lg">سلة المشتريات</h2>
              <div className="flex space-x-2 space-x-reverse">
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-gray-500 hover:text-destructive"
                  title="حذف الكل"
                  onClick={clearCart}
                  disabled={items.length === 0}
                >
                  <Trash2 className="h-5 w-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-gray-500 hover:text-primary"
                  title="تحديث"
                >
                  <RefreshCw className="h-5 w-5" />
                </Button>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 text-gray-600 uppercase">
                  <tr>
                    <th className="py-3 px-4 text-right">المنتج</th>
                    <th className="py-3 px-4 text-center">السعر</th>
                    <th className="py-3 px-4 text-center">الكمية</th>
                    <th className="py-3 px-4 text-center">المجموع</th>
                    <th className="py-3 px-4 text-center">إجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {items.length > 0 ? (
                    items.map((item) => (
                      <CartItem
                        key={item.productId}
                        item={item}
                        onUpdateQuantity={updateQuantity}
                        onRemove={removeItem}
                      />
                    ))
                  ) : (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-gray-500">
                        السلة فارغة. أضف منتجات للبدء.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
          
          {/* Popular Products */}
          <div className="mt-6">
            <h2 className="font-bold text-lg mb-4">المنتجات الشائعة</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {isLoadingPopular ? (
                // Skeleton loading state
                Array(6).fill(0).map((_, index) => (
                  <div key={index} className="bg-white rounded-lg shadow-sm overflow-hidden">
                    <Skeleton className="h-32 w-full" />
                    <div className="p-3">
                      <Skeleton className="h-5 w-3/4 mb-2" />
                      <div className="flex justify-between items-center">
                        <Skeleton className="h-5 w-20" />
                        <Skeleton className="h-8 w-8 rounded-full" />
                      </div>
                    </div>
                  </div>
                ))
              ) : popularProducts && popularProducts.length > 0 ? (
                popularProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={handleProductClick}
                  />
                ))
              ) : (
                <div className="col-span-3 text-center py-8 text-gray-500">
                  لا توجد منتجات متاحة
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Right Panel - Checkout */}
        <div className="w-1/3 bg-white border-r border-gray-200 flex flex-col">
          <CheckoutPanel
            cartItems={items}
            itemCount={totals.itemCount}
            subtotal={totals.subtotal}
            taxAmount={totals.taxAmount}
            total={totals.total}
            onCheckout={clearCart}
            invoiceContent={invoiceContent}
          />
        </div>
      </div>
    </>
  );
}
